package com.niit.Project.DAO;

import com.niit.Project.model.Cart;
import com.niit.Project.model.CartItem;

public interface BGCartItemDAO {

    void addCartItem(CartItem cartItem);

    void removeCartItem(CartItem cartItem);

    void removeAllCartItems(Cart cart);

    CartItem getCartItemByProductId(int productId);
}

