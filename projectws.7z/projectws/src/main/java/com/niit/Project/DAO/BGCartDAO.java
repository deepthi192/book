package com.niit.Project.DAO;


import java.io.IOException;
import com.niit.Project.model.Cart;

public interface BGCartDAO  {

    Cart getCartById(int cartId);

    Cart validate(int cartId) throws IOException;

    void update(Cart cart);

}


