package com.niit.Springmvc.service;

import java.util.List;

import com.niit.Springmvc.model.Empmodel;

public interface EmpService 
{
	public List<Empmodel> getAllEmployees();
}
