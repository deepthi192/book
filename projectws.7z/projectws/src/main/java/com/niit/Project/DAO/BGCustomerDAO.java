package com.niit.Project.DAO;

 
import java.util.List;

import com.niit.Project.model.Customer;

public interface BGCustomerDAO {

    void addCustomer(Customer customer);

    Customer getCustomerById(int customerId);

    List<Customer> getAllCustomers();

    Customer getCustomerByUsername(String username);
}

