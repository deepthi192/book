package com.niit.Project.controller.admin;

import com.niit.Project.model.Customer;
import com.niit.Project.model.Product;
import com.niit.Project.service.CustomerService;
import com.niit.Project.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/bgadmin")
public class BGAdminHome{

    @Autowired
    private ProductService productService;

    @Autowired
    private CustomerService customerService;

    @RequestMapping
    public String adminPage(){
        return "bgadmin";
    }

    @RequestMapping("/bgStock")
    public String bgStock(Model model){
        List<Product> products = productService.getProductList();
        model.addAttribute("products", products);

        return "bgStock";
    }

    @RequestMapping("/customer")
    public String customerManagerment(Model model){
        List<Customer> customerList = customerService.getAllCustomers();
        model.addAttribute("customerList", customerList);

        return "manageBGUsers";
    }


} // The End of Class;
