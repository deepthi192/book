package com.niit.Project.DAO;

import com.niit.Project.model.CustomerOrder;

public interface BGCustomerOrderDAO {

    void addCustomerOrder(CustomerOrder customerOrder);
}

