package com.niit.Project.service;

import com.niit.Project.model.Cart;

public interface CartService {

    Cart getCartById(int cartId);

    void update(Cart cart);
}
