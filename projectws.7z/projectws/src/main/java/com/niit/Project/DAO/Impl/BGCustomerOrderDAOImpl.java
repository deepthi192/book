package com.niit.Project.DAO.Impl;



import com.niit.Project.DAO.BGCustomerOrderDAO;
import com.niit.Project.model.CustomerOrder;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class BGCustomerOrderDAOImpl implements BGCustomerOrderDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public void addCustomerOrder(CustomerOrder customerOrder){
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(customerOrder);
        session.flush();
    }


} // The End of Class;

