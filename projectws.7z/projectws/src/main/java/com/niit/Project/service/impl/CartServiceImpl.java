package com.niit.Project.service.impl;


import com.niit.Project.DAO.BGCartDAO;
import com.niit.Project.model.Cart;
import com.niit.Project.service.CartService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CartServiceImpl implements CartService{

    @Autowired
    private BGCartDAO cartDao;

    public Cart getCartById(int cartId){
        return cartDao.getCartById(cartId);
    }

    public void update(Cart cart){
        cartDao.update(cart);
    }

} // The End of Class;
